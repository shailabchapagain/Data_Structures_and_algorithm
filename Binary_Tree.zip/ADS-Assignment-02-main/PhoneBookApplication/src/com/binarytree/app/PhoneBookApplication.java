package com.binarytree.app;

import java.util.Scanner;
import com.binarytree.core.BinaryTreeI;
import com.binarytree.core.impl.*;
/** Phone book application class to perform the phone book operations */

public class PhoneBookApplication {

	public static void main(String[] args) {
		System.out.println("*** Phonebook application started ***");
		BinaryTreeI tree = new BinaryTreeImpl();
		Scanner scanner = new Scanner(System.in);
		Scanner contactScanner = new Scanner(System.in);
		System.out.println("Select out of the following operations:");
		while (Boolean.TRUE) {
			System.out.println(
					"1. Insert a contact\n2. Delete a contact by name\n3. Search a contact by name\n4. List all\n5. Exit application");
			int choice = scanner.nextInt();
			String name;
			switch (choice) {
			case 1: 
					System.out.println("Enter the phonenumber:");
					String phone = contactScanner.next();
					System.out.println("Enter the name:");
					name = contactScanner.next();
					tree.insert(name, phone);
					System.out.println("Contact added successfully");
				break;
			case 2: System.out.println("Enter the contact name you want to delete:");
					name = contactScanner.next();
					tree.delete(name);
					System.out.println("Contact deleted successfully");
				break;
			case 3: System.out.println("Enter the contact name you want to search:");
					name = contactScanner.next();
					System.out.println("Contact Name: "+name+"\nPhone number: "+tree.search(name));
				break;
			case 4: tree.printInorder();
				break;
			default: System.exit(0);
			}
		}
		scanner.close();
		contactScanner.close();

	}

}
