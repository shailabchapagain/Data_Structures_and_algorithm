package com.binarytree.contact;
/**
 * Represents a single entry in a phone book.
 */
public class Contact {

	/**
	 * The name associated with this phone book entry.
	 */
	private String name;

	/**
	 * The phone number associated with this phone book entry.
	 */
	private String number;

	/**
	 * Creates a new phone book entry with the specified name and phone number.
	 *
	 * @param name   the name of the entry
	 * @param number the phone number of the entry
	 */
	public Contact(String name, String number) {
		this.name = name;
		this.number = number;
	}

	/**
	 * Returns the name associated with this phone book entry.
	 *
	 * @return the name of the entry
	 */
	public String getName() {
		return name;
	}

	/**
	 * Sets the name associated with this phone book entry.
	 *
	 * @param name the new name for the entry
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * Returns the phone number associated with this phone book entry.
	 *
	 * @return the phone number of the entry
	 */
	public String getNumber() {
		return number;
	}

	/**
	 * Sets the phone number associated with this phone book entry.
	 *
	 * @param number the new phone number for the entry
	 */
	public void setNumber(String number) {
		this.number = number;
	}

}
