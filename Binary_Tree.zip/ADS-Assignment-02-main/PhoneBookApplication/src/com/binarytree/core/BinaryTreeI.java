package com.binarytree.core;
/**
This interface represents a binary tree which contains names and phone numbers.
*/
public interface BinaryTreeI {

/**

Deletes a node with the given name from the binary tree.
@param name the name of the contact to be deleted
*/
void delete(String name);
/**

Inserts a new node with the given name and phone number into the binary tree.
@param name the name of the contact to be inserted
@param phoneNumber the phone number of the contact to be inserted
*/
void insert(String name, String phoneNumber);

/**
Searches for a node with the given name in the binary tree.
@param name the name of the node to be searched for
@return the phone number of the node with the given name, or null if the node is not found
*/
String search(String name);
/**

Prints the names of the nodes in the binary tree in inorder traversal.
*/
void printInorder();
}