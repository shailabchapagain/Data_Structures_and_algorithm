
package com.binarytree.core.impl;

import com.binarytree.contact.Contact;
import com.binarytree.core.BinaryTreeI;
/**
The BinaryTreeImpl class implements the BinaryTreeI interface and provides methods for printing, searching, adding, and removing nodes from a binary tree.
*/
public class BinaryTreeImpl implements BinaryTreeI {
	/**
	 * Declaring Root of binary tree
	 */
	private Node rootNode;

	/**
	 * Constructs a new BinaryTreeImpl object with a null root node.
	 */
	public BinaryTreeImpl() {
		this.rootNode = null;
	}

	/**
	 * Inner class of BinaryTreeImpl that defines a node in the tree.
	 */
	public class Node {
		/**
		 * PhoneBook object stored in each node
		 */
		private Contact contact;
		/**
		 * left child node
		 */
		private Node left;
		/**
		 * right child node
		 */
		private Node right;

		/**
		 * Constructs a new node with the given contact information.
		 *
		 * @param contact the contact information(contact object) to store in the node.
		 */
		public Node(Contact contact) {
			this.contact = contact;
			this.left = null;
			this.right = null;
		}
	}

	/**
	 * Adds a new node to the binary tree, helps in inserting phoneBook contacts.
	 *
	 * @param currentNode the current node being evaluated
	 * @param newNode     the new node to add.
	 */
	private void addNode(Node currentNode, Node newNode) {
		// If the new node's name is not equal to current node's name, insert it to the
		// left subtree
		if (newNode.contact.getName().compareTo(currentNode.contact.getName()) < 0) {
			if (currentNode.left == null) {
				// If Null, set the new node as the left child node
				currentNode.left = newNode;
			} else {
				// If Not NULL, call the addNode method on the left child node
				addNode(currentNode.left, newNode);
			}
			// else insert it to the right subtree
		} else {
			if (currentNode.right == null) {
				// If Null, set the new node as the right child node
				currentNode.right = newNode;
			} else {
				// If Not NULL, call the addNode method on the right child node
				addNode(currentNode.right, newNode);
			}
		}
	}

	/**
	 * Inserts a new phoneBook contact into the binary tree.
	 * 
	 * @param name        the name of the contact (used as the key)
	 * @param phoneNumber the phone number of the contact (the value)
	 */
	@Override
	public void insert(String name, String phoneNumber) { // Here, name is key and phoneNumber is value
		Contact contact = new Contact(name, phoneNumber);
		// If the binary tree is empty, set the new node as the root node
		if (rootNode == null) {
			rootNode = new Node(contact);
		} else {
			// If not empty then insert the contact into new node by calling addNode-
			// method
			addNode(rootNode, new Node(contact));
		}
	}

	/**
	 * provides the name searched for if present in the PhoneBook directory.
	 *
	 * @param name an object of type String Class
	 * @return the name of the contact of type String.
	 */

	@Override
	public String search(String name) {
		String ans = search_name(rootNode, name);

		return ans;
	}

	// search_name function will take root node and query name as input parameters

	/**
	 * Helper function for searching a particular contact in the PhoneBook
	 * directory.
	 * 
	 * @param rootNode Object of type Node that contains contact information.
	 * @param name     represents the name of contact to be looked for in the
	 *                 PhoneBook directory
	 * @return the name of the contact of type String.
	 */
	private String search_name(Node rootNode, String name) {
		// return null;

		// Base Cases:

		// 1) root is null

		if (rootNode == null) {
			return null;
		}

		// 2) name is present at root
		if (name.compareTo(rootNode.contact.getName()) == 0) {
			return rootNode.contact.getNumber();
		}

		// name is smaller than root's key
		if (name.compareTo(rootNode.contact.getName()) < 0) {
			return search_name(rootNode.left, name);
		}

		// Key is greater than root's key
		return search_name(rootNode.right, name);
	}

	/**
	 * This function is used to print the contact names stored in PhoneBook
	 * directory.
	 */
	@Override
	public void printInorder() {
		printInorderHelper(rootNode);
	}

	// printInorderHelper function will take root node as a parameter and print the
	// inorder traversal of the BST Tree.

	/**
	 * This is the helper function used to print contact names using inorder
	 * traversal.
	 * 
	 * @param rootNode represents the object of type Node
	 */
	private void printInorderHelper(Node rootNode) {

		if (rootNode == null) {
			return;
		}

		printInorderHelper(rootNode.left);

		System.out.println(rootNode.contact.getName() + ": " + rootNode.contact.getNumber());

		printInorderHelper(rootNode.right);

	}

	/**
	 * Removes a node from the binary tree.
	 *
	 * @param node the current node being evaluated
	 * @param name the name of the specific contact to be remove.
	 * @return the new root node of the tree after removal.
	 */
	private Node removeNode(Node node, String name) {
		if (node == null) {
			return null;
		}
		// If the given name is less than the current node's name, delete the node from
		// the left subtree
		if (name.compareTo(node.contact.getName()) < 0) {
			node.left = removeNode(node.left, name);
			// If the given name is greater than the current node's name, delete the node
			// from the right subtree
		} else if (name.compareTo(node.contact.getName()) > 0) {
			node.right = removeNode(node.right, name);
		} else {
			// If no child nodes then return null
			if (node.left == null && node.right == null) {
				return null;
				// If no left child node, return the right child node
			} else if (node.left == null) {
				return node.right;
				// If no right child node, return the left child node
			} else if (node.right == null) {
				return node.left;
			} else {
				// If the node has both left and right child nodes, traverse to find the minimum
				// node in the right subtree
				Node temp = node.right;
				while (temp.left != null) {
					temp = temp.left;
				}
				// Replace the current node with the minimum node
				node.contact = temp.contact;

				// Delete the contact of minimum node
				node.right = removeNode(node.right, temp.contact.getName());
			}
		}
		return node;
	}

	/**
	 * Delete a phoneBook contact as requested by user from the binary tree.
	 * 
	 * @param name the name of the contact to be deleted
	 */
	@Override
	public void delete(String name) {
		rootNode = removeNode(rootNode, name);
	}
}
