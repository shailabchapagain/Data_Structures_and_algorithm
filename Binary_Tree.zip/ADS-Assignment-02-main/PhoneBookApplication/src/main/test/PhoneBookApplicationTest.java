package main.test;

import java.util.*;

import com.binarytree.core.impl.BinaryTreeImpl;

public class PhoneBookApplicationTest {
    static BinaryTreeImpl binaryTreeImpl = new BinaryTreeImpl();
    static long startTime;
    static long elapsedTime;

    private static HashMap<String, String> contactHashMap() {
        HashMap<String, String> contacts = new HashMap<String, String>();
        contacts.put("John Doe", "+14155552671");
        contacts.put("Jane Smith", "+442032987654");
        contacts.put("Mike Johnson", "+917385932821");
        contacts.put("Emily Brown", "+61283071145");
        contacts.put("David Lee", "+813456789123");
        contacts.put("Lisa Kim", "+822593479876");
        contacts.put("Adam Wilson", "+2348059784321");
        contacts.put("Sarah Jones", "+972526098765");
        contacts.put("Juan Rodriguez", "+527223498765");
        contacts.put("Megan Taylor", "+61416003298");
        contacts.put("Aakash Singh", "+919876543210");
        contacts.put("Bhavna Patel", "+919999887766");
        contacts.put("Chandni Agarwal", "+918888776655");
        contacts.put("Deepak Sharma", "+919654321098");
        contacts.put("Ekta Verma", "+917834567890");
        contacts.put("Farhan Khan", "+919823456789");
        contacts.put("Gaurav Gupta", "+918765432109");
        contacts.put("Harshita Shah", "+917898765432");
        contacts.put("Ishaan Singh", "+919999999999");
        contacts.put("Jhanvi Desai", "+917777777777");
        contacts.put("Karan Patel", "+919876543210");
        contacts.put("Lata Iyer", "+918888888888");
        contacts.put("Manish Singh", "+919654321098");
        contacts.put("Neha Gupta", "+917834567890");
        contacts.put("Omkar Verma", "+919823456789");
        contacts.put("Pranav Patel", "+918765432109");
        contacts.put("Qureshi Ali", "+917898765432");
        contacts.put("Ravi Kumar", "+919999999999");
        contacts.put("Sakshi Mishra", "+917777777777");
        contacts.put("Tanvi Shah", "+919876543210");
        contacts.put("Urvashi Gupta", "+918888888888");
        contacts.put("Vikas Singh", "+919654321098");
        contacts.put("Waseem Khan", "+917834567890");
        contacts.put("Xander Patel", "+919823456789");
        contacts.put("Yash Iyer", "+918765432109");
        contacts.put("Zara Sheikh", "+917898765432");
        contacts.put("Aditi Chakraborty", "+919876543210");
        contacts.put("Bhanu Prakash", "+918888888888");
        contacts.put("Chitra Pandey", "+919654321098");
        contacts.put("Dhruv Joshi", "+917834567890");
        contacts.put("Esha Patel", "+919823456789");
        contacts.put("Faisal Khan", "+918765432109");
        contacts.put("Gagan Sharma", "+917898765432");
        contacts.put("Hitesh Gupta", "+919999999999");
        contacts.put("Isha Sharma", "+917777777777");
        contacts.put("Jasleen Kaur", "+919876543210");
        contacts.put("Kabir Singh", "+918888888888");
        contacts.put("Lakshmi Iyer", "+919654321098");
        contacts.put("Manav Patel", "+917834567890");
        contacts.put("Niharika Verma", "+919823456789");
        contacts.put("Amy Chang", "+8615660924654");
        contacts.put("Bryan Lee", "+821023847564");
        contacts.put("Catherine Hernandez", "+180426701234");
        contacts.put("Daniel Martinez", "+5215567894321");
        contacts.put("Elena Gomez", "+34608012345");
        contacts.put("Frank Kim", "+13108004433");
        contacts.put("Grace Lee", "+85296283456");
        contacts.put("Henry Nguyen", "+61421790698");
        contacts.put("Isabella Chen", "+8615902837421");
        contacts.put("Jake Wilson", "+16478537654");
        contacts.put("Karen Miller", "+19177776666");
        contacts.put("Liam Hernandez", "+639175432109");
        contacts.put("Maggie Brown", "+8613152873498");
        contacts.put("Nathan Davis", "+642154321");
        contacts.put("Olivia Taylor", "+919876543210");
        contacts.put("Patrick Chen", "+886922456789");
        contacts.put("Queenie Wong", "+85368234567");
        contacts.put("Rachel Kim", "+61418097654");
        contacts.put("Steven Chen", "+85261234567");
        contacts.put("Tina Zhang", "+8615012345678");
        contacts.put("Ursula Schmidt", "+498912345678");
        contacts.put("Victor Lee", "+13109997777");
        contacts.put("William Harris", "+18005551212");
        contacts.put("Xavier Hernandez", "+525555555555");
        contacts.put("Yuki Tanaka", "+81301234567");
        contacts.put("Zara Khan", "+971501234567");
        contacts.put("Adam Johnson", "+447876543210");
        contacts.put("Brianna Wilson", "+61412789654");
        contacts.put("Caleb Rodriguez", "+12195551234");
        contacts.put("Daniela Garcia", "+5216627894321");
        contacts.put("Ethan Davis", "+18002221234");
        contacts.put("Fiona Lee", "+85298765432");
        contacts.put("George Patel", "+917738493827");
        contacts.put("Hannah Kim", "+821063209876");
        contacts.put("Isaac Chen", "+61416325478");
        contacts.put("Jessica Brown", "+19122224444");
        contacts.put("Kevin Nguyen", "+61812341234");
        contacts.put("Lucas Kim", "+16501112222");
        contacts.put("Mia Jones", "+16315551234");
        contacts.put("Nate Smith", "+525540123456");
        contacts.put("Oliver Lee", "+61412678234");
        contacts.put("Peter Kim", "+821012345678");
        contacts.put("Quincy Wong", "+85261234568");
        contacts.put("Rebecca Chen", "+8618987654321");
        contacts.put("Samantha Miller", "+18001234567");
        contacts.put("Thomas Brown", "+13105551111");
        contacts.put("Uma Gupta", "+919876543210");
        contacts.put("Violetta Rodriguez", "+525556789012");
        contacts.put("William Davis", "+17865551234");
        contacts.put("Xin Liu", "+8613912345678");

        return contacts;
    }

    private static void insertTest() {
        HashMap<String, String> contacts = contactHashMap();

        startTime = System.nanoTime();
        contacts.entrySet().forEach(contact -> {
            binaryTreeImpl.insert(contact.getKey(), contact.getValue());
        });
        elapsedTime = System.nanoTime() - startTime;
        System.out.println("Insert for " + contacts.size() + " contacts: "+elapsedTime/1000000);
    }

    private static void deleteTest() {
        HashMap<String, String> contacts = contactHashMap();
        startTime = System.nanoTime();
        contacts.entrySet().forEach(contact -> {
            binaryTreeImpl.delete(contact.getKey());
        });
        elapsedTime = System.nanoTime() - startTime;
        System.out.println("Delete for " + contacts.size() + " contacts: "+elapsedTime/1000000);
    }

    private static void searchTest() {
        HashMap<String, String> contacts = contactHashMap();
        startTime = System.nanoTime();
        contacts.entrySet().forEach(contact -> {
            binaryTreeImpl.search(contact.getKey());
        });
        elapsedTime = System.nanoTime() - startTime;
        System.out.println("Search for " + contacts.size() + " contacts: "+elapsedTime/1000000);
    }

    public static void main(String args[]) {
        insertTest();
        deleteTest();
        searchTest();
    }
}
