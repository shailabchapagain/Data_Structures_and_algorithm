# ADS-Assignment-5
Solving a transportation related problem utilizing Graphs data structure in java
