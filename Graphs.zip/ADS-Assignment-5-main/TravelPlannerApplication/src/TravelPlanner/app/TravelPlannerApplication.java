package TravelPlanner.app;

import TravelPlanner.core.GraphImpl;

import java.util.ArrayList;
import java.util.Scanner;


/**
 *  The TravelPlannerApplication class is a CLI for checking the shortest distance between two cities.
 *  It can be used by the travellers to find the shortest distance between two places in order to plan their trip
 *  in the best possible manner.
 */

public class TravelPlannerApplication {

	/**
	 * Main method for running the TravelPlannerApplication CLI
	 *
	 */

	public static void main(String[] args) {

		GraphImpl graph = new GraphImpl();

		TravelPlannerOperation tpo = new TravelPlannerOperation(graph);

		try (Scanner scanner = new Scanner(System.in)) {
			while(true)
			{

				System.out.print("Enter the '1 ' to add cities, enter '2' to find shortest distance between cities and enter '3' to exit");
				String checkWord = scanner.next();

				switch (checkWord)
				{
					case "1":
						System.out.println("Please enter source, destination and distance");
						String src = scanner.next();
						String dest = scanner.next();

						int dist = scanner.nextInt();
						graph.addEdge(src,dest,dist);
						break;
					case "2":
						System.out.println("Please enter the source city");
						String source = scanner.next();

						System.out.println("Please enter the destination city");
						String destination = scanner.next();

						Integer min_dist = tpo.minDistanceBetweenTwoPlaces(source, destination);
						ArrayList<String> shortest_path = tpo.pathWithMinDistance(source, destination, min_dist);
						System.out.println("Shortest distance between " + source + " and " + destination + " is " + min_dist);
						System.out.println("And the shortest path is "+shortest_path);
			            break;
					case "3":
						System.exit(0);
			            break;
					
					default:
						System.out.println("Invalid Value. Please enter correct Value");
						break;
				}
			}
		}
	}


}
