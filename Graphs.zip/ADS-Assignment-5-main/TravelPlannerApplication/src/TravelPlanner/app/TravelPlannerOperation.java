package TravelPlanner.app;

import java.util.*;

import TravelPlanner.core.GraphImpl;
import TravelPlanner.core.GraphImpl.Edge;

/**
 * TravelPlannerOperation class implements the
 * finctionality of Dijkstra's and DFS Algorithm. 
 * These algorithms will help us find the shortest 
 * distance and path between the source and destination node.
 */
public class TravelPlannerOperation {
    GraphImpl graph;
    ArrayList<String> min_path;

    /**
     * Constuctor to set the value of initialization
     * 
     * @param graph: The complete weighted graph
     */
    TravelPlannerOperation(GraphImpl graph) {
        this.graph = graph;
    }


    /**
     * minDistanceBetweenTwoPlaces method will internally call
     * the dijkstra method to return the value of the
     * minimum distance between the two cities.
     * 
     * @param src: Source city name
     * @param dest: Destination city name
     * @returns minimum distance between src and dest
     */
    Integer minDistanceBetweenTwoPlaces(String src, String dest) {
        return dijkstra(src, dest);
    }
    

    /**
     * pathWithMinDistance method will internally call
     * the dfs method to return the value of the
     * shortest path between the two cities.
     * 
     * @param src: Source city name
     * @param dest: Destination city name
     * @min_dist: minimum distance between the 2 cities
     * @returns minimum distance between src and dest
     */
    ArrayList<String> pathWithMinDistance(String src, String dest, Integer min_dist) {
        min_path = new ArrayList<String>();
        Map<String, Boolean> visited = new HashMap<String, Boolean>(){{
            put(src, true);
        }};
        ArrayList<String> path = new ArrayList<String>();
        path.add(src);

        dfs(visited, src, dest, path, min_dist, 0);

        return min_path;
    }

    /**
     * sptSetnode method will make new node of the city and its 
     * distance using Map and return it.
     * 
     * @param node: City name
     * @param weight: Distance from the src city
     * 
     * @returns Map of node and weight
     */
    Map<Integer, String> sptSetNode(String node, int weight) {
        Map<Integer, String> newNode = new HashMap<Integer, String>();
        newNode.put(0, node);
        newNode.put(1, String.valueOf(weight));
        return newNode;
    }


    /**
     * dijkstra method will run the Dijkstra's Algorithm
     * to find the min distance between the source and 
     * all the other nodes. At last this function will 
     * return the minimum distance between the source
     * and the destination city.
     * 
     * @param src: Source city name
     * @param dest: Destination city name
     * 
     * @returns the minimum distance between the src and dest
     */
    Integer dijkstra(String src, String dest)
    {
        Map<String, Integer> dist = new HashMap<String, Integer>();
        ArrayList<Map<Integer, String>> sptSet = new ArrayList<Map<Integer, String>>();

        dist.put(src, 0);
        sptSet.add(sptSetNode(src, 0));
        int i = 0;

        while (i<sptSet.size()) {
            String node = sptSet.get(i).get(0);
            i++;

            for (Edge e: graph.getNeighbors(node)) {
                String nextNode = e.getDest();
                int weight = e.getDistance();

                if (dist.getOrDefault(nextNode, Integer.MAX_VALUE) > dist.getOrDefault(node, Integer.MAX_VALUE) + weight) {
                    if (dist.containsKey(nextNode)) {
                        dist.replace(nextNode, dist.get(node) + weight);
                    } else {
                        dist.put(nextNode, dist.get(node) + weight);
                    }
                    sptSet.add(sptSetNode(nextNode, dist.get(nextNode)));
                }
            }
        }

        return dist.get(dest);
    }


    /**
     * dfs method will go through the graph
     * in a depth first search manner to find 
     * the path with the smallest distance and
     * return it.
     * 
     * @param visited: will track if the particular node is visited or not
     * @param src: Source city name
     * @param dest: Destination City name
     * @param path: path of the cities being visited
     * @param min_dist: shortest distance between the 2 cities
     * @param curr_dist: Current distance between the 2 cities
     */
    void dfs(
        Map<String, Boolean> visited, 
        String src, 
        String dest, 
        ArrayList<String> path, 
        Integer min_dist, 
        Integer curr_dist) {

        if (src.equals(dest) && min_dist.equals(curr_dist)) {
                min_path.addAll(path);
                return;
            } else {
                for (Edge e: graph.getNeighbors(src)) {
                    String node = e.getDest();
                    Integer dist = e.getDistance();
                    if (!visited.containsKey(node)) {
                        visited.put(node, true);
                        path.add(node);
                        dfs(visited, node, dest, path, min_dist, curr_dist+dist);
                        int index = path.size()-1;
                        path.remove(index);
                    }
                }
            }
            visited.remove(src);
    }
}
