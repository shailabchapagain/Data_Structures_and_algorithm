package TravelPlanner.core;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * GraphImpl Class implements the basic functionality of 
 * graph data structure.It is customized for Travel Planner Application to
 * store weighted values with city names and the distance between them.
 *
 */
public class GraphImpl {
	
	/**
	 * A static Edge class is used to define a edge between a source city 
	 * and a destination city along with the distance between them.
	 */
	
	public static class Edge {
	    private String dest;
	    private int distance;
	    
	    /**
	     * Constructor to set the values for initialization.
	     * 
	     * @param dest: The destination city name
	     * @param distance: The distance between cities
	     */
	    
	    Edge(String dest, int distance) {
	            this.dest = dest;
	            this.distance = distance;
	        }
	    
	    public String getDest() {
            return dest;
        }

        public int getDistance() {
            return distance;
        }
	}
	
	
    private Map<String, List<Edge>> graph;
    
    /**
     * Constructor to create a HashMap to store edges for a graph
     * for all the sources.
     */
    
    public GraphImpl() {
        graph = new HashMap<>();
    }

    /**
     * addEdge method to add edges for a graph given the source, destination and distance.
     * Creates an ArrayList for each source and keeps adding destination vertices 
     * for every edge added. This basically creates an adjacency list for
     * the graph.
     * 
     *  @param src: Source city name
     *  @param dest: Destination city name
     *  @param distance: Distance between cities
     */
    
    public void addEdge(String src, String dest, int distance) {
        graph.computeIfAbsent(src, k -> new ArrayList<>()).add(new Edge(dest, distance));
        graph.computeIfAbsent(dest, k -> new ArrayList<>()).add(new Edge(src, distance));
    }
    
    /**
     * Method to get all the neighboring cities for a source city.
     * 
     *@param: Source city to find the neighbors for
     *@returns list of adjacent cities along with the weights
     */
    public List<Edge> getNeighbors(String city) {
        return graph.getOrDefault(city, new ArrayList<>());
    }
    
    
    
    /**
     * Remove city from the graph
     * @param city
     * @return list of connected edges to the city
     */
    public List<Edge> removeCity(String city) {
		return graph.remove(city);
    }
    
}
