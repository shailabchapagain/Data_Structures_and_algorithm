package test;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;

import TravelPlanner.core.GraphImpl;

/**
 * This test class tests and records the performance of the graph implementation class. It tests the add edge, remove 
 * city and get neighbours methods of the graph.
 */
public class GraphImplTest {

    private static final String CHARACTERS = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
    private static final int STRING_LENGTH = 5;


    /** Generates a random 5 letter city name
     * @return city name
     */
    public static String generateRandomString() {
        Random random = new Random();
        StringBuilder stringBuilder = new StringBuilder();

        for (int i = 0; i < STRING_LENGTH; i++) {
            int randomIndex = random.nextInt(CHARACTERS.length());
            char randomChar = CHARACTERS.charAt(randomIndex);
            stringBuilder.append(randomChar);
        }

        return stringBuilder.toString();
    }

    /** A static method to test the add edge functionality of graph
     * @param graph instance
     * @return list of cities added as vertices
     */
    private static Set<String> testAddEdge(GraphImpl graph) {
    	Runtime runtime = Runtime.getRuntime();
    	long memoryBefore, memoryAfter, memoryUsed;
    	long startTime, endTime, elapsedTime;

    	Random random = new Random();
    	int numOfVertices = 10000;
    	List<String> cityNames = new ArrayList<>();
        for (int i = 0; i < numOfVertices; i++) {
            cityNames.add(generateRandomString());
        }

        int numOfEdges = 500000;
        Set<String> vertexCities = new HashSet<>();
        startTime = System.currentTimeMillis();
        memoryBefore = runtime.totalMemory() - runtime.freeMemory();
        for (int i = 0; i < numOfEdges; i++) {
            String from = cityNames.get(random.nextInt(numOfVertices));
            String to = cityNames.get(random.nextInt(numOfVertices));
            int weight = from.equals(to)? 0 : random.nextInt();
            vertexCities.add(from);
            vertexCities.add(to);
            graph.addEdge(from, to, weight);
        }
        endTime = System.currentTimeMillis();
        memoryAfter = runtime.totalMemory() - runtime.freeMemory();
        elapsedTime = endTime - startTime;
        memoryUsed = (memoryAfter - memoryBefore)/(1024*1024);

        System.out.println("Time taken for insertion of "+numOfEdges+" edges: " + elapsedTime + " milliseconds");
        System.out.println("Memory used for insertion of "+numOfEdges+" edges: " + memoryUsed + " MB");
        return vertexCities;
    }

    /**
     * Test get operation of the graph by fetching the neighbors of each city
     * @param graph
     * @param cityNames
     */
    private static void testGetNeighbours(GraphImpl graph, Set<String> cityNames) {
    	Runtime runtime = Runtime.getRuntime();
    	long memoryBefore, memoryAfter, memoryUsed;
    	long startTime, endTime, elapsedTime;
    	startTime = System.currentTimeMillis();
        memoryBefore = runtime.totalMemory() - runtime.freeMemory();
    	cityNames.forEach(city -> {
    		graph.getNeighbors(city);
    	});
    	 endTime = System.currentTimeMillis();
         memoryAfter = runtime.totalMemory() - runtime.freeMemory();
         elapsedTime = endTime - startTime;
         memoryUsed = (memoryAfter - memoryBefore)/(1024);
         System.out.println("Time taken to fetch neighbours for "+cityNames.size()+" cities: " + elapsedTime + " milliseconds");
         System.out.println("Memory used to fetch neighbours for "+cityNames.size()+" cities: " + memoryUsed + " KB");
    }

    /**
     * Method to test the performance of removing a vertex from the graph. 
     * @param graph
     * @param cityNames
     */
    private static void testRemoveVertex(GraphImpl graph, Set<String> cityNames) {
    	Runtime runtime = Runtime.getRuntime();
    	long memoryBefore, memoryAfter, memoryUsed;
    	long startTime, endTime, elapsedTime;
    	startTime = System.currentTimeMillis();
        memoryBefore = runtime.totalMemory() - runtime.freeMemory();
    	cityNames.forEach(city -> {
    		graph.removeCity(city);
    	});
    	 endTime = System.currentTimeMillis();
         memoryAfter = runtime.totalMemory() - runtime.freeMemory();
         elapsedTime = endTime - startTime;
         memoryUsed = (memoryAfter - memoryBefore)/(1024);
         System.out.println("Time taken to remove "+cityNames.size()+" cities: " + elapsedTime + " milliseconds");
         System.out.println("Memory used to remove "+cityNames.size()+" cities: " + memoryUsed + " KB");
	}

	/**
	 * Main method that tests the prime graph operations - add, get and remove
	 * @param args
	 */
	public static void main(String[] args) {
		GraphImpl graph = new GraphImpl();
		Set<String> cityNames = testAddEdge(graph);
		testGetNeighbours(graph, cityNames);
		testRemoveVertex(graph, cityNames);
	}


}