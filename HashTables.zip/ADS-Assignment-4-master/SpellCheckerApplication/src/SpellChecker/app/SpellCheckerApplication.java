package SpellChecker.app;

import java.util.List;
import java.util.Scanner;

/**
 * The SpellCheckerApplication class is a CLI for a spell-checking application.
 * It provides the user with the ability to check the spelling of words and get
 * possible corrections for misspelled words based on a custom dictionary.
 * 
 * The application distinguishes between admin users and regular users. Admin
 * users have the ability to add, remove, and check words in the custom
 * dictionary, while regular users can only spell check words and find possible
 * corrections.
 */
public class SpellCheckerApplication {

	/**
	 * A constant to add a word to the set of words present in hashtable
	 */
	public static final String PRESENT = "P";

	/**
	 * Main method for running the SpellCheckerApplication CLI.
	 * 
	 */
	public static void main(String[] args) {

		SpellCheckerOperations oprObj = new SpellCheckerOperations();
		Scanner scanner = new Scanner(System.in);

		System.out.print("Are you an admin or a user? (type 'admin' or 'user'): ");
		String userType = scanner.nextLine().toLowerCase();
		switch (userType) {
		case "admin":
			processAdminExecutionFlow(oprObj, scanner);
			break;
		case "user":
			processGeneralUsersExecutionFlow(oprObj, scanner);
			break;
		default:
			System.out.println("Invalid user type. Exiting the application.");
			break;
		}
		scanner.close();
	}

	/**
	 * A static void method that processes the general Users' execution flow by
	 * allowing them to check if the word is spelt correctly. It also provides an
	 * enhanced feature of auto-correcting the words based on character difference
	 * of 1.
	 * 
	 * @param oprObj:  The SpellCheckerOperatons instance
	 * @param scanner: The scanner instance to accept user-input
	 */
	private static void processGeneralUsersExecutionFlow(SpellCheckerOperations oprObj, Scanner scanner) {
		while (true) {
			System.out.print("Enter the word you want to find possible corrections for or enter '$' to exit: ");
			String checkWord = scanner.nextLine().toLowerCase();
			if (checkWord.equals("$")) {
				System.exit(0);
			}
			System.out.println(
					"The word " + checkWord + " is: " + (oprObj.customDictionary.get(checkWord) != null ? "present"
							: "not known to this custom dictionary"));

			List<String> result = oprObj.getCorrections(checkWord);

			if (result.contains(checkWord)) {
				System.out.println("The word " + checkWord + " is spelled correctly!");
			} else if (result.isEmpty()) {
				System.out.println(
						"No possible autocorrections found in the custom dictionary for the word " + checkWord);
			} else {
				System.out.println("Possible autocorrects for " + checkWord + ":");
				System.out.println(result);
			}
		}
	}

	/**
	 * The static void method processes the Admin execution flow by providing
	 * options to add, remove, and check if words exist in the custom built
	 * dictionary
	 * 
	 * @param oprObj   : The SpellCheckerOperations instance
	 * @param scanner: The scanner instance to accept user-input
	 */
	private static void processAdminExecutionFlow(SpellCheckerOperations oprObj, Scanner scanner) {
		while (true) {
			System.out.print("Enter the operation command to perform (add/remove/ifExists/exit): ");
			String operation = scanner.nextLine().toLowerCase();
			String word;
			switch (operation) {
			case "add":
				System.out.print("Enter the word: ");
				word = scanner.nextLine().toLowerCase();
				if (oprObj.customDictionary.get(word) == null) {
					oprObj.customDictionary.put(word, PRESENT);
					System.out.println("Word added successfully.");
				} else {
					System.out.println("The word is already present in the custom dictionary.");
				}
				break;
			case "remove":
				System.out.print("Enter the word: ");
				word = scanner.nextLine().toLowerCase();
				String removedstring = oprObj.customDictionary.remove(word);
				if (removedstring == null) {
					System.out.println("The word does not exist in the custom dictionary.");
				} else {
					System.out.println("Word removed successfully.");
				}
				break;
			case "ifexists":
				System.out.print("Enter the word: ");
				word = scanner.nextLine().toLowerCase();
				String string = oprObj.customDictionary.get(word);
				if (string == PRESENT) {
					System.out.println("The word exists in the custom dictionary");
				} else {
					System.out.println("The word does not exist in the custom dictionary.");
				}
				break;
			case "exit":
				System.exit(0);
			default:
				System.out.println("Invalid operation. Try again.");
				break;
			}
		}
	}
}
