package SpellChecker.app;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import SpellChecker.core.HashTable;

/**
 * SpellCheckOperations Class is used to implement the operation of finding
 * possible corrections for a word using the custom dictionary.
 * 
 */

public class SpellCheckerOperations {

	public HashTable<String, String> customDictionary = new HashTable<>();

	/**
	 * Constructor to load the custom dictionary from text file.
	 */
	public SpellCheckerOperations() {
		this.readKeyValuePairsFromFile();
	}

	/**
	 * Get list of all possible corrections for a word by comparing it with words
	 * from custom dictionary. In this method, we are only checking for one
	 * character difference between words of same length to give auto corrected
	 * words.
	 * 
	 * @param word: word to find the auto corrections for
	 * @return List of words that are possible auto corrections.
	 */

	public List<String> getCorrections(String word) {
		List<String> result = new ArrayList<>();
		for (int i = 0; i < word.length(); i++) {
			StringBuilder sb = new StringBuilder(word);
			for (char c = 'a'; c <= 'z'; c++) {
				sb.setCharAt(i, c);
				String s = sb.toString();
				if (customDictionary.get(s) != null && !result.contains(s)) {
					result.add(s);
				}
			}
		}
		return result;
	}

	/**
	 * Method to read custom dictionary words from a text file. These words are
	 * inserted into customDictionary hash table using put method of HashTable
	 * Class.
	 */

	public void readKeyValuePairsFromFile() {
		String filePath = new File("").getAbsolutePath();
		if (!filePath.contains("SpellCheckerApplication")) {
			filePath+=("/SpellCheckerApplication");
		}
		BufferedReader reader;
		try {
			reader = new BufferedReader(new FileReader(filePath + "/DefaultDictionary.txt"));
			String line = null;
			while ((line = reader.readLine()) != null) {
				String[] pair = line.split(",");
				customDictionary.put(pair[0], pair[1]);
			}

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
