package SpellChecker.core;

/**
 * An interface enforcing the users to implement the basic operations of
 * hash-table. Can be implemented by HashTable, HashMap, HashSet, etc.
 *
 * @param <K>: key of generic type
 * @param <V>: value of generic type
 */
public interface HashI<K, V> {

	void put(K key, V value);

	V get(K key);

	V remove(K key);

}
