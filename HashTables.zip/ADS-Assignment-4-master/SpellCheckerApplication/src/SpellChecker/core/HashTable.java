package SpellChecker.core;

import java.util.LinkedList;

/**
 * The HashTable class implements the HashI interface's methods, providing their
 * definition. Its generic nature allows insertion of any type of object into
 * the hash table.
 * 
 */
public class HashTable<K, V> implements HashI<K, V> {
	private static final int DEFAULT_CAPACITY = 16;
	private LinkedList<Entry<K, V>>[] hashtable;

	public HashTable() {
		this(DEFAULT_CAPACITY);
	}

	/**
	 * Constructor to initialize the hash-table capacity
	 * 
	 * @param capacity: holds the capacity value
	 */
	@SuppressWarnings("unchecked")
	public HashTable(int capacity) {
		hashtable = new LinkedList[capacity];
		for (int i = 0; i < capacity; i++) {
			hashtable[i] = new LinkedList<>();
		}
	}

	/**
	 * This method will put the key-value pair in the hash-table. Appropriate index
	 * will be fetched after hashing of the key and value will be inserted.
	 * 
	 * @param key:   Generic key
	 * @param value: Generic value
	 */
	@Override
	public void put(K key, V value) {
		int index = getIndex(key);
		LinkedList<Entry<K, V>> bucket = hashtable[index];
		for (Entry<K, V> entry : bucket) {
			if (entry.key.equals(key)) {
				entry.value = value;
				return;
			}
		}
		bucket.add(new Entry<>(key, value));
	}

	/**
	 * The get method will fetch the value mapped to the key in the hash-table.
	 * 
	 * @param key: Generic key
	 * @returns value associated with the key
	 */
	@Override
	public V get(K key) {
		int index = getIndex(key);
		LinkedList<Entry<K, V>> bucket = hashtable[index];
		for (Entry<K, V> entry : bucket) {
			if (entry.key.equals(key)) {
				return entry.value;
			}
		}
		return null;
	}

	/**
	 * The remove method is responsible to remove the key-value pair present in
	 * hash-table using key as identifier.
	 * 
	 * @param key: The key to remove
	 * @returns value of the key that was removed
	 *
	 */
	@Override
	public V remove(K key) {
		int index = getIndex(key);
		LinkedList<Entry<K, V>> bucket = hashtable[index];
		for (Entry<K, V> entry : bucket) {
			if (entry.key.equals(key)) {
				V removedValue = entry.value;
				bucket.remove(entry);
				return removedValue;
			}
		}
		return null;
	}

	/**
	 * The method fetches the index of the bucket for the key provided after
	 * applying the hash function
	 * 
	 * @param key: The key
	 * @return an index of the buckets of the hash-table
	 */
	private int getIndex(K key) {
		return (key.hashCode() & 0x7fffffff) % hashtable.length;
	}

	/**
	 * 
	 * An entry static class to store the key value pair
	 * 
	 * @param <K> : key of generic type
	 * @param <V> : value of generic type
	 */
	private static class Entry<K, V> {
		private K key;
		private V value;

		public Entry(K key, V value) {
			this.key = key;
			this.value = value;
		}
	}
}
