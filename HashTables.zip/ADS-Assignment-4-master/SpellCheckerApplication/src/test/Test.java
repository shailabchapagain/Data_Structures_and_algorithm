package test;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

import SpellChecker.core.HashTable;

/**
 * This is a Test Class to test  the functionalities of Hash Table.
 * It involves methods to test put, get, and remove methods for Hash Table
 */
public class Test {
    static long startTime;
    static long elapsedTime;
    static HashTable<String, String> hashTable = new HashTable<>();

    private static ArrayList<String[]> wordsList() {
        ArrayList<String[]> words = new ArrayList<String[]>();
        String filePath = new File("").getAbsolutePath();
		if (!filePath.contains("SpellCheckerApplication")) {
			filePath+=("/SpellCheckerApplication");
		}
		BufferedReader reader;
		try {
			reader = new BufferedReader(new FileReader(filePath + "/DefaultDictionary.txt"));
			String line = null;         
			while ((line = reader.readLine()) != null)
			{
				String[] pair = line.split(",");
                words.add(pair);      
			}
		
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
            e.printStackTrace();
        }

        return words;
    }

    /**
     * Testing the Put method for Hash Table.
     * Time analysis using start time and elapsed time
     */
    private static void testPut() {
        ArrayList<String[]> words = wordsList();

        startTime = System.nanoTime();
        words.forEach(word -> {
            hashTable.put(word[0], word[1]);
        });
        elapsedTime = System.nanoTime() - startTime;
        System.out.println("Put for " + words.size() + " words: "+elapsedTime/1000000);
    }

    /**
     * Testing the Get method for Hash Table.
     * Time analysis using start time and elapsed time
     */
    private static void testGet() {
        ArrayList<String[]> words = wordsList();

        words.forEach(word -> {
            hashTable.put(word[0], word[1]);
        });

        startTime = System.nanoTime();
        words.forEach(word -> {
            hashTable.get(word[0]);
        });
        elapsedTime = System.nanoTime() - startTime;
        System.out.println("Get for " + words.size() + " words: "+elapsedTime/1000000);
    }

    /**
     * Testing the Remove method for Hash Table.
     * Time analysis using start time and elapsed time
     */
    private static void testRemove() {
        ArrayList<String[]> words = wordsList();

        words.forEach(word -> {
            hashTable.put(word[0], word[1]);
        });
        
        startTime = System.nanoTime();
        words.forEach(word -> {
            hashTable.remove(word[0]);
        });
        elapsedTime = System.nanoTime() - startTime;
        System.out.println("Remove for " + words.size() + " words: "+elapsedTime/1000000);
    }

    public static void main(String[] args) {
        testPut();
        testGet();
        testRemove();
    }
}
