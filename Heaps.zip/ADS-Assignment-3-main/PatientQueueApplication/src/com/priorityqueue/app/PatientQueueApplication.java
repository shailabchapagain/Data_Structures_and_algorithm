package com.priorityqueue.app;

import java.util.Scanner;

import com.priorityqueue.core.PriorityQueueI;
import com.priorityqueue.core.heapImpl.HeapImpl;
import com.priorityqueue.core.sortedseqImpl.SortedSeqImpl;
import com.priorityqueue.core.unsortedseqImpl.UnsortedSeqImpl;
import com.priorityqueue.patient.Patient;

/**
 * The PatientQueueApplication class is the execution point of the application. The application will facilitate the end-user
 *  to verify different operations of the priority queue implemented using Heap, Sorted sequence and Unsorted sequence. 
 */
public class PatientQueueApplication {
    public static void main(String[] args) {
    	System.out.println("*** Patient management application started ***");
		PriorityQueueI runtimeImpl = null;
		Scanner scanner = new Scanner(System.in);
		System.out.println("Select out of the following implementations:");
		System.out.println("1. Heap\n2. SortedSequence\n3. UnsortedSequence");
		int choice = scanner.nextInt();
		switch(choice) {
			case 1: runtimeImpl = new HeapImpl();
					break;
			case 2: runtimeImpl = new SortedSeqImpl();
					break;
			case 3: runtimeImpl = new UnsortedSeqImpl();
					break;
			default: System.exit(0);
		}
		Scanner patientScanner = new Scanner(System.in);
		System.out.println("Operations:");
		while (Boolean.TRUE) {
			System.out.println(
					"1. Admit a patient\n2. Discharge the most critical patient\n3. Find the most critical patient\n4. Exit application");
			choice = scanner.nextInt();
			String name;
			switch (choice) {
			case 1: 
					System.out.println("Enter the name of the patient:");
					name = patientScanner.next();
					System.out.println("Enter "+name+"'s priority:");
					int priority = patientScanner.nextInt();
					Patient patient = new Patient(name, priority);
					runtimeImpl.add(patient);
					System.out.println("Patient has been admitted");
					break;
			case 2: 
					Patient dischargedPatient = runtimeImpl.poll();
					if(dischargedPatient != null) {
						System.out.println(dischargedPatient.getName()+" has been discharged.");
					} else {
						System.out.println("Hospital doesn't have any patients to discharge.");
					}
					break;
			case 3: 
					Patient criticalPatient = runtimeImpl.peek();
					if(criticalPatient != null) {
						System.out.println(criticalPatient.getName()+" is the most critical patient at the moment.");
					} else {
						System.out.println("No patients found.");
					}
					break;
			default: System.exit(0);
			}
		}
		scanner.close();
		patientScanner.close();
    }
}
