/**
 * com.priorityqueue.core.PriorityQueueI
 * 
 * This interface defines the basic operations for a priority queue of patients.
 * The priority queue is used to manage patients according to their priority levels.
 * The higher the priority of a patient, the sooner they will be attended to.
 * 
 */
package com.priorityqueue.core;

import com.priorityqueue.patient.Patient;

public interface PriorityQueueI {
	/**
	 * Retrieves, but does not remove, the patient with the highest priority from
	 * this priority queue.
	 * 
	 * @return The patient with the highest priority, or null if this priority queue
	 *         is empty.
	 */
	public Patient peek();

	/**
	 * Retrieves and removes the patient with the highest priority from this
	 * priority queue.
	 * 
	 * @return The patient with the highest priority, or null if this priority queue
	 *         is empty.
	 */
	public Patient poll();

	/**
	 * Inserts the specified patient into this priority queue according to the
	 * patient's priority.
	 * 
	 * @param patient The patient to be inserted into the priority queue.
	 */
	public void add(Patient patient);

}
