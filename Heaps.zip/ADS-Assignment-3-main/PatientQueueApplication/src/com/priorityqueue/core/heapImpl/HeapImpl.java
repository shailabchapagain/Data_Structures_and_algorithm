/**
* com.priorityqueue.core.heapImpl
* 
* HeapImpl is a min-heap implementation of the PriorityQueueI interface.
* This class represents a priority queue using an ArrayList to store Patient objects.
* Each Patient has an associated priority value and with lower values representing higher priority.

*/
package com.priorityqueue.core.heapImpl;

import java.util.ArrayList;

import com.priorityqueue.core.PriorityQueueI;
import com.priorityqueue.patient.Patient;

public class HeapImpl implements PriorityQueueI {
	/**
	 * Arraylist of patient type
	 */
	private ArrayList<Patient> patients;

	/**
	 * Default constructor, initializes an empty priority queue.
	 */
	public HeapImpl() {
		this.patients = new ArrayList<>();
	}

	/**
	 * Returns the index of the left child of the specified node.
	 *
	 * @param index The index of the parent node.
	 * @return The index of the left child.
	 */
	private int getLeftChildIndex(int index) {
		return 2 * index + 1;
	}

	/**
	 * Returns the index of the right child of the specified node.
	 *
	 * @param index The index of the parent node.
	 * @return The index of the right child.
	 */
	private int getRightChildIndex(int index) {

		return 2 * index + 2;
	}

	/**
	 * Returns the index of the parent of the specified node.
	 *
	 * @param index The index of the child node.
	 * @return The index of the parent node.
	 */
	private int getParentIndex(int index) {

		return (index - 1) / 2;
	}

	/**
	 * Checks if the specified node has a left child.
	 *
	 * @param index The index of the node to check.
	 * @return True if the node has a left child, otherwise false.
	 */
	private boolean hasLeftChild(int index) {

		return getLeftChildIndex(index) < patients.size();
	}

	/**
	 * Checks if the specified node has a right child.
	 *
	 * @param index The index of the node to check.
	 * @return True if the node has a right child, otherwise false.
	 */
	private boolean hasRightChild(int index) {

		return getRightChildIndex(index) < patients.size();
	}

	/**
	 * Checks if the specified node has a parent.
	 *
	 * @param index The index of the node to check.
	 * @return True if the node has a parent, otherwise false.
	 */
	private boolean hasParent(int index) {

		return getParentIndex(index) >= 0;
	}

	/**
	 * Swaps the elements at the specified indices in the patients ArrayList.
	 *
	 * @param indexOne The index of the first element to swap.
	 * @param indexTwo The index of the second element to swap.
	 */
	private void swap(int indexOne, int indexTwo) {
		Patient temp = patients.get(indexOne);
		patients.set(indexOne, patients.get(indexTwo));
		patients.set(indexTwo, temp);
	}

	/**
	 * Returns the highest-priority Patient without removing it from the priority
	 * queue.
	 *
	 * @return The highest-priority Patient or null if the priority queue is empty.
	 */
	@Override
	public Patient peek() {
		if (patients.size() == 0) {
			return null;
		}
		return patients.get(0);
	}

	/**
	 * Returns and removes the highest-priority Patient from the priority queue.
	 *
	 * @return The highest-priority Patient or null if the priority queue is empty.
	 */
	@Override
	public Patient poll() {
		if (patients.size() == 0) {
			return null;
		}
		Patient item = patients.get(0);
		patients.set(0, patients.get(patients.size() - 1));
		patients.remove(patients.size() - 1);
		heapifyDown(0);
		return item;
	}

	/**
	 * Moves the specified node downwards in the heap until it satisfies the
	 * min-heap property.
	 *
	 * @param index The index of the node to be moved downwards.
	 */
	private void heapifyDown(int index) {

		while (hasLeftChild(index)) {
			int minChildIndex = getLeftChildIndex(index);

			if (hasRightChild(index) && patients.get(getRightChildIndex(index)).getPriority() < patients
					.get(getLeftChildIndex(index)).getPriority()) {
				minChildIndex = getRightChildIndex(index);
			}

			if (patients.get(index).getPriority() <= patients.get(minChildIndex).getPriority()) {
				break;
			} else {
				swap(index, minChildIndex);
			}
			index = minChildIndex;
		}
	}

	/**
	 * Adds a Patient to the priority queue.
	 *
	 * @param patient The Patient to be added to the priority queue.
	 */
	@Override
	public void add(Patient patient) {
		patients.add(patient);
		heapifyUp(patients.size() - 1);
	}

	/**
	 * Moves the specified node upwards in the heap until it satisfies the min-heap
	 * property.
	 *
	 * @param index The index of the node to be moved upwards.
	 */
	private void heapifyUp(int index) {
		while (hasParent(index)
				&& patients.get(index).getPriority() < patients.get(getParentIndex(index)).getPriority()) {
			swap(index, getParentIndex(index));
			index = getParentIndex(index);
		}
	}

}
