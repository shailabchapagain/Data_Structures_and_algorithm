package com.priorityqueue.core.sortedseqImpl;

import com.priorityqueue.core.PriorityQueueI;
import com.priorityqueue.patient.Patient;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import java.util.Comparator;

/**
 * This class provides implementation of priority queues using sorted sequence/List.
 */

public class SortedSeqImpl implements PriorityQueueI {

    private List<Patient> patientsSortedQueue;

    public SortedSeqImpl() {
        this.patientsSortedQueue = new ArrayList<>();
    }



    /**
     *     comparator class to sort according to a user-defined object which is an object of type Patient class in this case
     *
     *     here Comparator interface is implmented by PatientComparator class that is used
     *     to sort the Patient class objects based on the priority value associated with them.
     */

    // created a comparator class to sort according to a user-defined object which is an object of type Patient class in this case.

    public class PatientComparator implements Comparator<Patient> {
        @Override
        public int compare(Patient patient1, Patient patient2) {
            return Integer.compare(patient1.getPriority(), patient2.getPriority());
        }
    }

    /**
     * this function will return the patient with highest priority.
     * @return an object of type Patient.
     */

    @Override
    public Patient peek() {

        return patientsSortedQueue.size() > 0 ? patientsSortedQueue.get(0): null;

    }

    /**
     * this function will fetch and remove the patient with the highest priority.
     *
     *
     * @return Patient object having maximum priority.
     */
    @Override
    public Patient poll() {

        // if queue is empty it would throw an exception.
        if(patientsSortedQueue.size() == 0)
        {
            return null;
        }

       // storing the patient with the highest priority(here the priority is given to patient with the least priority value).
        Patient min = patientsSortedQueue.remove(0);
        Comparator<Patient> patientComparator = new PatientComparator();
        // passing an object of type patientComparator class inorder to sort based on the comparator class.
        Collections.sort(patientsSortedQueue,patientComparator);
        return min;
    }

    /**
     * this function will add a new patient to the priority queue.
     * @param patient object of type Patient class.
     *
     */


    @Override
    public void add(Patient patient) {

        patientsSortedQueue.add(patient);

        Comparator<Patient> patientComparator = new PatientComparator();
        Collections.sort(patientsSortedQueue,patientComparator);

    }



    /**
     * this function will check if the queue is priority empty or not.
     *
     * @return returns a boolean value of true or false.
     */
    public boolean isEmpty() {
        return patientsSortedQueue.isEmpty();
    }

}
