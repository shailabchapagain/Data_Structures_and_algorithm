package com.priorityqueue.core.unsortedseqImpl;

import com.priorityqueue.core.PriorityQueueI;
import com.priorityqueue.patient.Patient;

import java.util.ArrayList;
import java.util.List;

/**
 * This class provides implementation of priority queues using unsorted sequence/List.
 */

public class UnsortedSeqImpl implements PriorityQueueI {

    private List<Patient> patientsUnsortedQueue;

    public UnsortedSeqImpl() {
        this.patientsUnsortedQueue = new ArrayList<>();
    }


    /**
     * this function will return the patient with highest priority.
     * @return an object of type Patient.
     */

    @Override
    public Patient peek() {

        int minIndex = 0;
        for (int i = 1; i < patientsUnsortedQueue.size(); i++) {
            if (patientsUnsortedQueue.get(i).getPriority() < patientsUnsortedQueue.get(minIndex).getPriority()) {
                minIndex = i;
            }
        }
        return patientsUnsortedQueue.size() > 0 ? patientsUnsortedQueue.get(minIndex): null;
    }

    /**
     * this function will fetch and remove the patient with the highest priority.
     *
     *
     * @return Patient object having maximum priority.
     */

    @Override
    public Patient poll() {

        if(patientsUnsortedQueue.size() == 0)
        {
            return null;
        }

        int minIndex = 0;
        for (int i = 1; i < patientsUnsortedQueue.size(); i++) {
            if (patientsUnsortedQueue.get(i).getPriority() < patientsUnsortedQueue.get(minIndex).getPriority()) {
                minIndex = i;
            }
        }
        return patientsUnsortedQueue.remove(minIndex);

    }

    /**
     * this function will add a new patient to the priority queue.
     * @param patient object of type Patient class.
     *
     */

    @Override
    public void add(Patient patient) {
        patientsUnsortedQueue.add(patient);
    }

    /**
     * this function will check if the queue is priority empty or not.
     *
     * @return returns a boolean value of true or false.
     */
    public boolean isEmpty() {
        return patientsUnsortedQueue.isEmpty();
    }
    
}
