package main.test;

import java.util.HashMap;

import com.priorityqueue.core.heapImpl.HeapImpl;
import com.priorityqueue.core.sortedseqImpl.SortedSeqImpl;
import com.priorityqueue.core.unsortedseqImpl.UnsortedSeqImpl;
import com.priorityqueue.patient.Patient;


/**
 * This is a Test Class to test  the functionalities of Priority Queue.
 * It involves methods to test insert,peek and poll methods for Priority Queue
 * Heap , Sorted Sequence and Unsorted Sequence are used to implement Priority Queue
 */
public class Test {    	
    	static long startTime;
        static long elapsedTime;
        static HeapImpl heapImpl = new HeapImpl(); 
        static SortedSeqImpl sortedSeq = new SortedSeqImpl();
        static UnsortedSeqImpl unsortedSeq = new UnsortedSeqImpl();

        private static HashMap<String, Integer> patientsHashMap() {
        	HashMap<String, Integer> patients = new HashMap<String, Integer>();
            patients.put("John Doe",10);      	
            patients.put("Jane Smith",20);		
            patients.put("Mike Johnson",41);	
            patients.put("Emily Brown",62);		
            patients.put("David Lee",37);		
            patients.put("Lisa Kim",42);		
            patients.put("Adam Wilson",53);		
            patients.put("Sarah Jones",5);		
            patients.put("Juan Rodriguez",12);	
            patients.put("Megan Taylor",43);	
            patients.put("Aakash Singh",29);
            patients.put("Bhavna Patel",31);
            patients.put("Chandni Agarwal",8);
            patients.put("Deepak Sharma",33);
            patients.put("Ekta Verma",85);
            patients.put("Farhan Khan",98);
            patients.put("Gaurav Gupta",75); 
            patients.put("Harshita Shah",21);
            patients.put("Ishaan Singh",66);
            patients.put("Jhanvi Desai",76); 
            patients.put("Karan Patel",6);
            patients.put("Lata Iyer",11);
            patients.put("Manish Singh",95); 
            patients.put("Neha Gupta",81);
            patients.put("Omkar Verma",49);
            patients.put("Pranav Patel",61); 
            patients.put("Qureshi Ali",100);
            patients.put("Ravi Kumar",59);
            patients.put("Sakshi Mishra",17);
            patients.put("Tanvi Shah",91);
            patients.put("Urvashi Gupta",39);
            patients.put("Vikas Singh",88);
            patients.put("Waseem Khan",25);
            patients.put("Xander Patel",71);
            patients.put("Yash Iyer",60);
            patients.put("Zara Sheikh",30);
            patients.put("Aditi Chakrabor",92);			
            patients.put("Bhanu Prakash",77);           
            patients.put("Chitra Pandey",63);           
            patients.put("Dhruv Joshi",1);              
            patients.put("Esha Patel",13 );             
            patients.put("Faisal Khan",51);             
            patients.put("Gagan Sharma",2);             
            patients.put("Hitesh Gupta",97);           	
            patients.put("Isha Sharma",52);             
            patients.put("Jasleen Kaur",89);            
            patients.put("Kabir Singh",9);
            patients.put("Lakshmi Iyer",82);
            patients.put("Manav Patel",34);
            patients.put("Niharika Verma",22);
            patients.put("Amy Chang",15);
            patients.put("Bryan Lee",3);
            patients.put("Catherine Herna4",99);
            patients.put("Daniel Martinez",83);
            patients.put("Elena Gomez",16);
            patients.put("Frank Kim",80);
            patients.put("Grace Lee",64);
            patients.put("Henry Nguyen",50); 
            patients.put("Isabella Chen",90);
            patients.put("Jake Wilson",72);
            patients.put("Karen Miller",7);
            patients.put("Liam Hernandez",4);
            patients.put("Maggie Brown",93);
            patients.put("Nathan Davis",32);
            patients.put("Olivia Taylor",24);
            patients.put("Patrick Chen",19);
            patients.put("Queenie Wong",28);
            patients.put("Rachel Kim",84);
            patients.put("Steven Chen",96);
            patients.put("Tina Zhang",35);
            patients.put("Ursula Schmidt",18);
            patients.put("Victor Lee",14);
            patients.put("William Harris",48);
            patients.put("Xavier Hernande",67);
            patients.put("Yuki Tanaka",54);
            patients.put("Zara Khan",70);
            patients.put("Adam Johnson",94); 
            patients.put("Brianna Wilson",23);
            patients.put("Caleb Rodriguez",87);
            patients.put("Daniela Garcia",55);
            patients.put("Ethan Davis",44);
            patients.put("Fiona Lee",46);
            patients.put("George Patel",73); 
            patients.put("Hannah Kim",58);
            patients.put("Isaac Chen",27);
            patients.put("Jessica Brown",40);
            patients.put("Kevin Nguyen",57); 
            patients.put("Lucas Kim",26);
            patients.put("Mia Jones",38);
            patients.put("Nate Smith",36);
            patients.put("Oliver Lee",86);
            patients.put("Peter Kim",47);
            patients.put("Quincy Wong",65);
            patients.put("Rebecca Chen",74);
            patients.put("Samantha Miller",45);
            patients.put("Thomas Brown",79);
            patients.put("Uma Gupta",56);
            patients.put("Violetta Rodrig",69);
            patients.put("William Davis",68);
            patients.put("Xin Liu",78);

            return patients;
          
        }
        
        /**
         * Testing the Insert method for Priority Queue using Heap.
         * Time analysis using start time and elapsed time
         */
        
        private static void insertTestHeap() {
            HashMap<String, Integer> patients = patientsHashMap();

            startTime = System.nanoTime();
            patients.entrySet().forEach(patient -> {
                heapImpl.add(new Patient(patient.getKey(), patient.getValue()));
            });
            elapsedTime = System.nanoTime() - startTime;
            System.out.println("Insert for " + patients.size() + " patients: "+elapsedTime/1000000);
        }
        
        /**
         * Testing the Insert method for Priority Queue using Sorted Sequence.
         * Time analysis using start time and elapsed time
         */
        
        private static void insertTestSortedSeq() {
            HashMap<String, Integer> patients = patientsHashMap();

            startTime = System.nanoTime();
            patients.entrySet().forEach(patient -> {
                sortedSeq.add(new Patient(patient.getKey(), patient.getValue()));
            });
            elapsedTime = System.nanoTime() - startTime;
            System.out.println("Insert for " + patients.size() + " patients: "+elapsedTime/1000000);
        }
        
        /**
         * Testing the Insert method for Priority Queue using Unsorted Sequence.
         * Time analysis using start time and elapsed time
         */
        
        private static void insertTestUnsortedSeq() {
            HashMap<String, Integer> patients = patientsHashMap();

            startTime = System.nanoTime();
            patients.entrySet().forEach(patient -> {
                unsortedSeq.add(new Patient(patient.getKey(), patient.getValue()));
            });
            elapsedTime = System.nanoTime() - startTime;
            System.out.println("Insert for " + patients.size() + " patients: "+elapsedTime/1000000);
        }
        
        /**
         * Testing the Peek method for Priority Queue using Heap.
         * Time analysis using start time and elapsed time
         */
        
        private static void peekTestHeap() {
        	
            startTime = System.nanoTime();
            Patient peekData = heapImpl.peek();
            elapsedTime = System.nanoTime() - startTime;
            System.out.println(peekData.getName() + " " + peekData.getPriority());
            System.out.println("Peek Operation: "+(double)(elapsedTime)/1000000);
        }
        
        /**
         * Testing the Peek method for Priority Queue using Sorted Sequence.
         * Time analysis using start time and elapsed time
         */
        
        private static void peekTestSortedSeq() {
        	
            startTime = System.nanoTime();
            Patient peekData = sortedSeq.peek();
            elapsedTime = System.nanoTime() - startTime;
            System.out.println(peekData.getName() + " " + peekData.getPriority());
            System.out.println("Peek Operation: "+(double)(elapsedTime)/1000000);
        }
        
        /**
         * Testing the Peek method for Priority Queue using Unsorted Sequence.
         * Time analysis using start time and elapsed time
         */
        
        
        private static void peekTestUnsortedSeq() {
        	
            startTime = System.nanoTime();
            Patient peekData = unsortedSeq.peek();
            elapsedTime = System.nanoTime() - startTime;
            System.out.println(peekData.getName() + " " + peekData.getPriority());
            System.out.println("Peek Operation: "+(double)(elapsedTime)/1000000);
        }
        
        /**
         * Testing the Poll method for Priority Queue using Heap.
         * Time analysis using start time and elapsed time
         */
        
        private static void pollTestHeap() {
        	
            startTime = System.nanoTime();
            Patient peekData = heapImpl.poll();
            elapsedTime =System.nanoTime() - startTime;
            System.out.println(peekData.getName() + " " + peekData.getPriority());
            System.out.println("Poll Operation: "+ (double)(elapsedTime)/1000000);
        }
        
        /**
         * Testing the Poll method for Priority Queue using Sorted Sequence.
         * Time analysis using start time and elapsed time
         */
        
        private static void pollTestSortedSeq() {
        	
            startTime = System.nanoTime();
            Patient peekData = sortedSeq.poll();
            elapsedTime = System.nanoTime() - startTime;
            System.out.println(peekData.getName() + " " + peekData.getPriority());
            System.out.println("Poll Operation: "+(double)(elapsedTime)/1000000);
        }
        
        /**
         * Testing the Poll method for Priority Queue using Unsorted Sequence.
         * Time analysis using start time and elapsed time
         */
        
        private static void pollTestUnsortedSeq() {
        	
            startTime = System.nanoTime();
            Patient peekData = unsortedSeq.poll();
            elapsedTime = System.nanoTime() - startTime;
            System.out.println(peekData.getName() + " " + peekData.getPriority());
            System.out.println("Poll Operation: "+(double)(elapsedTime)/1000000);
        }
        

        public static void main(String[] args) {
        patientsHashMap();
        insertTestHeap();
        peekTestHeap();
        pollTestHeap();
        insertTestSortedSeq();
        peekTestSortedSeq();
        pollTestSortedSeq();
        insertTestUnsortedSeq();
        peekTestUnsortedSeq();
        pollTestUnsortedSeq();
    }

}
