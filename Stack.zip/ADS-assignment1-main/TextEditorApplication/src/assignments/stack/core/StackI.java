package assignments.stack.core;

public interface StackI {

	void push(String text);
	
	String pop();
	
	String peek();
}
