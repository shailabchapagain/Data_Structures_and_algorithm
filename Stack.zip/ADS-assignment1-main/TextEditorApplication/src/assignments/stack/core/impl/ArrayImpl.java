/**
 * 
 */
package assignments.stack.core.impl;

import assignments.stack.core.StackI;

import java.util.ArrayList;

public class ArrayImpl implements StackI{
	private ArrayList<String> textElements;	//stack elements will be stored in this array

	public ArrayImpl(){
		this.textElements = new ArrayList<String>();
	}

	@Override
	public void push(String text) {
		textElements.add(text);	//adding the text into the array list
	}

	@Override
	public String pop() {
		if (textElements.isEmpty()) {
			return null;
		}
		String popText = textElements.get(textElements.size() - 1);
		textElements.remove(textElements.size() - 1);
		return popText;
	}

	@Override
	public String peek() {
		if (textElements.isEmpty()) {
			return null;
		}
		return textElements.get(textElements.size() - 1);
	}

	public ArrayList<String> getTextElements() {
		return this.textElements;
	}
}
