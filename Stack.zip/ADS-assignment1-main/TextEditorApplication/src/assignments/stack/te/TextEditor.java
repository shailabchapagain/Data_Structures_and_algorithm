package assignments.stack.te;



import java.util.Scanner;

import assignments.stack.te.impl.Operations;

public class TextEditor {

	public static void main(String[] args) {
        //instance of operation class
		Operations operation = new Operations();
        //reading input from user
        Scanner scanner = new Scanner(System.in);
        String input;
        boolean exit = false;

        while (!exit) {
            System.out.println("Enter a command (add, undo, redo, display, exit): ");
            input = scanner.nextLine();

            switch (input.toLowerCase()) {
                case "add":
                    System.out.println("Enter text to add: ");
                    String text = scanner.nextLine();
                    operation.addText(text);
                    System.out.println("Text added.");
                    break;

                case "undo":
                	operation.undo();
                    System.out.println("Undo completed.");
                    break;
                    
                case "redo":
    				operation.redo();
                    System.out.println("redo completed.");
                    break;
                    
                case "display":
                    System.out.println(operation.getAll());
                    break;

                case "exit":
                    exit = true;
                    System.out.println("Exiting program.");
                    break;
                
                default:
                    System.out.println("Invalid command.");
                    break;
            }
            System.out.println("");
            System.out.println("Current text: " + operation.getText());
            System.out.println("");
        }

        scanner.close();
		
	}

}
