package assignments.stack.te.impl;

import java.util.ArrayList;

import assignments.stack.core.impl.ArrayImpl;

public class Operations {
    private ArrayImpl undo;
    private ArrayImpl redo;

    public Operations() {

        undo = new ArrayImpl();
        redo = new ArrayImpl();
    }

   //adding the text into the array list
    public void addText(String text) {
        undo.push(text);
    }

    // remove the top element of stack
    public void undo() {
    	
    	 redo.push(undo.peek());
         undo.pop();
         
    }
    
    public void redo() {
    	
   	   // pushing text elements into the undo stack 
    	undo.push(redo.peek());
    	// removing the top text element from the redo stack.
        redo.pop();
        
   }

   // retrieve top element of stack
    public String getText() {
        return undo.peek();
    }
    
    public String getAll() {
    	ArrayList<String> textItems = undo.getTextElements();
    	StringBuilder text = new StringBuilder();
    	textItems.forEach(textI -> {text.append(textI).append("\n");});
    	return text.toString();
    }
}
